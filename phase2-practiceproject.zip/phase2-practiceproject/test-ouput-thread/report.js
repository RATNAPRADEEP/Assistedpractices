$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"52c36a83-4074-4e95-8200-daa1a2396173","feature":"Test the Wiki page on chrome Browser","scenario":"Test Login link on Wiki Page","start":1697787113722,"group":1,"content":"","tags":"@all,@login,@functional,","end":1697787130392,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});