package javaprograms;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 1;
		
		// start the loop
		while(i<=10) {
			
			// loop statements
			
			System.out.println(i);
			i++;
			
		}
		
		
		System.out.println("Printed values form 1 to 10");

	}

}
