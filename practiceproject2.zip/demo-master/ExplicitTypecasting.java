

public class ExplicitTypecasting {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Explicit typecasting demo
		
		// int size is just 4 bytes, double size is 8 bytes
		
		double a=11.4;
		
		
		 // int b;
		
		// Convert a variable which is a double into integer
		
		int b = (int)a ; // value of double a is now has datatype int
		
		System.out.println(b);
		
		
		
	}

}
