package javaprograms;

public class ForLoop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Learning Java";

		for(int i=0;i<s.length();i++){
		    char ch = s.charAt(i);
		    System.out.println(ch+" ");
		}

	}

}
