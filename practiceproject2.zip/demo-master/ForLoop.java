package javaprograms;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<6;i++) {
			System.out.println("hello world");
		}

	}

}
