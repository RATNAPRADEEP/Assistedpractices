package javaprograms;

public class DoWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 1;
		
		do {
		
		System.out.println("Today is Wednesday");
		i++; // increment the value of i by 1
		
		}
		while(i>=7);
		
		
		System.out.println("Printed the messages. I am out of the loop");


	}

}
