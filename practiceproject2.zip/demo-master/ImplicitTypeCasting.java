

public class ImplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// implicit typecasting demo
		
		// int size is just 4 bytes, double size is 8 bytes
		
		int a=10;
		
		 // double b;
		
		// Convert a which is an integer into double
		
		double b = a ; // value of int a is now has datatype double
		
		System.out.println(b);
		
		
		
	}

}
