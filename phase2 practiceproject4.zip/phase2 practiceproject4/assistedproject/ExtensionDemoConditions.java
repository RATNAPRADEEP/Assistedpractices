package com.app.junitDemo;

public class ExtensionDemoConditions {

}
